copy the shelf tool into

"..\Documents\houdini19.5\toolbar"

and you should get a shelf named "Felix" with the tool.
The script only works on selected matnet nodes, containing principled shaders.


You can also create your own shelf button by just pasting the script from the .txt file


It only considers material name and base color.


